sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("cdsbasicapp.controller.View1",{onInit(){}})});
//# sourceMappingURL=View1.controller.js.map